#include <iostream>
#include <string>
#include "shape.h"

int main() {
    size_t x, y, w, h;

    std::cin >> w >> h;
    Canvas canvas{h, w};


    return 0;
}